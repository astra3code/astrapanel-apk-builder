package site.wolftz

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.VibrationEffect
import android.os.Vibrator
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private val startUrl = "https://wolftz.site"
    private val appHost = "wolftz.site"
    private lateinit var web: WebView
    @Volatile private var bridgeAllowed = false
    private var swipeRef: SwipeRefreshLayout? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val pickFiles = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        web = findViewById(R.id.webview)
        val swipe = findViewById<SwipeRefreshLayout>(R.id.swipe)
        swipeRef = swipe
        swipe.setOnRefreshListener { web.reload() }
        swipe.setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false
        }

        web.addJavascriptInterface(AstraNativeBridge(), "AstraNative")

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                bridgeAllowed = isAppUrl(url)
            }
            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                bridgeAllowed = isAppUrl(url)
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme ?: return false
                if (scheme == "http" || scheme == "https") {
                    val h = uri.host ?: return false
                    if (h == appHost || h.endsWith(".$appHost")) return false
                    return openExternal(uri)
                }
                return openExternal(uri)
            }
            override fun onPageFinished(view: WebView, url: String) {
                swipe.isRefreshing = false
                if (isAppUrl(url)) view.evaluateJavascript("window.WTN=window.AstraNative;window.dispatchEvent(new Event('astranative:ready'))", null)
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) view.loadUrl("file:///android_asset/offline.html")
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try { pickFiles.launch(params.createIntent()); true } catch (e: Exception) { fileCallback = null; false }
            }
        }

        web.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val name = URLUtil.guessFileName(url, contentDisposition, mimeType)
                val req = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimeType)
                    .addRequestHeader("User-Agent", userAgent)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(this, "Downloading $name", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                openExternal(Uri.parse(url))
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(startUrl)
    }

    private fun isAppUrl(url: String?): Boolean {
        val h = try { Uri.parse(url ?: "").host } catch (e: Exception) { null } ?: return false
        return h == appHost || h.endsWith(".$appHost")
    }

    /** JavaScript bridge: window.AstraNative (alias window.WTN). Only works on pages from the app's own site. */
    inner class AstraNativeBridge {
        private fun ui(block: () -> Unit) { if (bridgeAllowed) runOnUiThread { try { block() } catch (e: Exception) {} } }

        @JavascriptInterface fun isApp(): Boolean = true

        @JavascriptInterface fun getDeviceInfo(): String {
            if (!bridgeAllowed) return "{}"
            val pi = packageManager.getPackageInfo(packageName, 0)
            return JSONObject()
                .put("platform", "android").put("brand", Build.BRAND).put("model", Build.MODEL)
                .put("osVersion", Build.VERSION.RELEASE).put("sdk", Build.VERSION.SDK_INT)
                .put("appVersion", pi.versionName ?: "").put("packageName", packageName).toString()
        }

        @JavascriptInterface fun toast(message: String) = ui { Toast.makeText(this@MainActivity, message.take(200), Toast.LENGTH_SHORT).show() }

        @JavascriptInterface fun vibrate(ms: Int) = ui {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            val d = ms.coerceIn(1, 5000).toLong()
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(d, VibrationEffect.DEFAULT_AMPLITUDE)) else @Suppress("DEPRECATION") v.vibrate(d)
        }

        @JavascriptInterface fun haptic(style: String) = vibrate(when (style) { "heavy" -> 60; "medium" -> 35; else -> 15 })

        @JavascriptInterface fun share(title: String, text: String, url: String) = ui {
            val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_SUBJECT, title).putExtra(Intent.EXTRA_TEXT, listOf(text, url).filter { it.isNotBlank() }.joinToString("\n"))
            startActivity(Intent.createChooser(i, title.ifBlank { null }))
        }

        @JavascriptInterface fun copy(text: String) = ui {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("text", text))
        }

        @JavascriptInterface fun setStatusBar(color: String, darkIcons: Boolean) = ui {
            window.statusBarColor = Color.parseColor(color)
            WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = darkIcons
        }

        @JavascriptInterface fun setPullToRefresh(enabled: Boolean) = ui {
            swipeRef?.isEnabled = enabled
        }

        @JavascriptInterface fun openExternal(url: String) = ui {
            val u = Uri.parse(url)
            if (u.scheme == "http" || u.scheme == "https") this@MainActivity.openExternal(u)
        }

        @JavascriptInterface fun closeApp() = ui { finish() }
    }

    private fun openExternal(uri: Uri): Boolean {
        return try { startActivity(Intent(Intent.ACTION_VIEW, uri)); true } catch (e: Exception) { true }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }
}
